import React, { Component } from 'react'
import {SERVER_BASE_URL, ACCESS_TOKEN} from '../constants'



class AddUsers extends Component {
    constructor(props){
        super(props);
        this.state={
         name:'',
         email:'',
         password:'',
         Isactive:false         
        }
        //this.handleChecked = this.handleChecked.bind(this);
      }

      handleChecked = (e) => {
        e.preventDefault();


        this.setState((prevState, props) => {
          //console.log(prevState, props);
          return {Isactive: !prevState.Isactive}
        });

        console.log(e.target.checked)

        //console.log(e.target);



        //this.setState({ Isactive: e.target.checked });

        console.log(typeof(e.target.checked));
      }

      submit(){
     console.log(this.state.Isactive);
       let url=SERVER_BASE_URL+`profile/`;
        let data= this.state;
        fetch(url,{
          method:'POST',
          headers:{
            'Accept':'application/json',
            'Content-type': 'application/json',
            'Authorization': `Bearer ${ACCESS_TOKEN}`
          },
          body: JSON.stringify(data)
        }).then((result) =>{
          result.json().then((resp)=>{
         console.warn('resp', resp)
         alert('data is submited');
          })
        })
      }
      render() {
       const {editItem} = this.props
         return(
            <div className="content-wrapper">
           <section className="content-header">
			      	<h1>Organization</h1>
			   </section>
            <section className="content">
            <div className="row">
					<div className="col text-right mb-25p">
						<a href="#"><button className="btn text-right add"><span className="f-14p white"> <i class="fas fa-clipboard-list"></i> View Details</span></button></a>
					</div>
				</div>
        <div className="card border-0 editorganization-form-container shadow-sm ">
					<div className="card-body question-card-body">
						<div className="border-bottom ptb-5 whitebg">
							<h6 className="pb-2 inline detail">Add Organization</h6>
						</div>
            <div>
							<table className="bg-white editorganization-table ">
              <tr className="bb-none">
									<td className="w-40 text-left">Username</td>
									<td className="text-left "><input className="textinput name border" type="text"  value={this.state.name} name="name" onChange={(data) =>
        {this.setState({name:data.target.value})}}/></td>
								</tr>
								<tr className="bb-none">
									<td className="w-40 text-left">Usertype</td>
									<td className="text-left "><input className="contact border" type="text"  pattern="/^\$/$"  value={this.state.email} name="email"
        onChange={(data) =>{this.setState({email:data.target.value})}}/></td>
								</tr>
								<tr className="bb-none">
									<td className="w-40 text-left">LoginID</td>
									<td className="text-left "><input className="email border" type="text" value={this.state.loginId} name="loginId" onChange={(data) =>
        {this.setState({loginId:data.target.value})}} /></td>
								</tr>
                <tr className="bb-none">
									<td className="w-40 text-left">Password</td>
									<td className="text-left "><input className="email border" type="text" value={this.state.password} name="password" onChange={(data) =>
        {this.setState({password:data.target.value})}}/></td>
								</tr>
                <tr className="bb-none">
									<td className="w-40 text-left  pt-30"></td>
									<td className="text-left pt-20 " >
										<div className="myTest custom-control custom-checkbox">
										  <input type="checkbox" className="custom-control-input" id="customCheck1" name="Isactive" onChange={this.handleChecked}/>
										  <label className="custom-control-label" for="customCheck1">Is Active</label>
										</div>
									</td>
								</tr>
                <tr className="bb-none">
									<td className="w-40 text-left  pt-30"></td>
									<td className="text-left pt-20 " >
										 <div className="w-216p">
											 <button className="btn btn-primary mr-29p w-108p save" onClick={()=>{this.submit()}}>Save</button>
											 <button className="btn btn-danger w-108p cancel">cancel</button>
										 </div>
									</td>
								</tr>
                </table>
                </div>
                </div>
                </div>
               
                    </section>
            
            
            </div>
        )
      }
    }
        

export {AddUsers};