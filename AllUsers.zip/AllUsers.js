import React, { Component, Profiler } from 'react'
import {SERVER_BASE_URL} from '../constants'
import {Link} from 'react-router-dom'


class AllUsers extends Component {
  
  constructor(props) {
    super(props);
    this.state = {   
      error:null,
      editing:false,
      data: []
    };
  }

     componentDidMount() {
        fetch(SERVER_BASE_URL+"profile/")
        .then((Response) => Response.json())
           .then((findresponse) =>
                {
                     this.setState({ data: findresponse })
                },
                (error) => {
                  this.setState({ error });
                }
                )
    }

    
// Edit Button 
handleEditButton = (id, data)=> {
  
  fetch(SERVER_BASE_URL+`profile/${id}`, {
    method: 'PUT',
    body: JSON.stringify(data),
    headers: {
        'Content-Type': 'application/json'
        
    }
}).then(res => {
    return res;
}).catch(err => err);
  }

    render() {

      let TBody = [];

      this.state.data.map((dynamicData, indx) =>{
        //console.log(dynamicData, indx);

        let org = dynamicData.OrganizationUsers.length ? dynamicData.OrganizationUsers[0] : {};
        let role = dynamicData.RoleId.length ? dynamicData.RoleId[0] : {};
        let tbodyContent = (<>
        
                              <tr className="trow" key={indx}>
                                <td className="h-50p">{dynamicData.name}</td>
                                <td className="h-50p"></td>
                                <td className="h-50p">{role.RoleName}</td>
                                <td className="h-50p green">{org.IsActive ? "Active" :"Inactive"}</td> 
                <td>
              
                <button type="button" className="btn" onClick={() => this.handleEditButton()}><span className="mx-2 text-primary">
                       <i className="fas fa-pen" aria-hidden="true"/> Edit
                </span></button>

                 </td>
                              </tr>
                            </>
                            );

        TBody.push(tbodyContent);
      });

        return (
            <div className="content-wrapper">
                <section className="content-header">
        <h1>All Organizations</h1>
        </section>
                {/* table allusers */}
                <section className="content">
               <div className="row">
               <div className="col text-right mb-25p">
               <button className="btn text-right add"><Link to="/addusers"><i className="fas fa-plus white" /><span className="f-14p white"> Add New</span></Link></button>
            </div>
               
               </div>
                
                
                     
               <div className="card border-0 organization-form-container">
               <div className="card-body">
               <div className="border-bottom flex-justify-between">
                    <p className="darkblue">You have 40 organization in total</p>
                   
                </div>
               
  <div className="table-responsive">
    <table className="organization-table">
      <thead className="thead-block">
        <tr><th className="h-50p">Username</th><th className="h-50p">Usertype</th><th className="h-50p">LoginID</th><th className="h-50p">Status</th><th className="h-50p">Action</th></tr>
      </thead>
      
          <tbody id="cursorPointer">
            {TBody} 
           
             
          </tbody>
         
    </table> 
   </div>
</div>
</div>
   </section>
            </div>    
        );
    }
}
export {AllUsers};